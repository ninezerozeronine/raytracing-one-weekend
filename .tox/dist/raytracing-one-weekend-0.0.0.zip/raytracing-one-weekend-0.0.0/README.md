# Ray Tracing in one weekend - Python

Running throughthe guide at https://raytracing.github.io/books/RayTracingInOneWeekend.html 
to create a raytracer.